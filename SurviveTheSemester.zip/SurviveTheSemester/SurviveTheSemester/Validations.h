#pragma once

bool isInputValid();